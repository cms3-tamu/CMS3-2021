### Advanced use of linear solvers: elastic polycrystal
### FFTMAD version 05/2019
### Linear simulation, Microstructre from external file

from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from INPUT.read_RVE import read_RVE
from POST.toParaview import toParaview
import numpy as np

folder='results/'

my_simulation=simulation('Test_polyX_1','non-linear','variational-nw-cg-finite')
my_simulation.set_options(nlgeom='yes')
#define options
#define options
my_simulation.set_options(threads=8,nlgeom='yes',parallel_mat='umat-omp',fftlib='FFTW',einsumlib='f2py')
my_simulation.set_tolerances(toler_nw=1e-5,toler_lin=1e-6,maxiter_cg=1000)

# Reading  the microstructure    
my_simulation.ndim,my_simulation.n,my_simulation.L,\
my_simulation.prop=read_RVE('micro128x128x1.dx')
print('shape prop',np.shape(my_simulation.prop))


# Material models and Properties
my_materials,orientations=[],[] # 
num_grains = np.max(my_simulation.prop)+1
ffm = open(folder+'pmat.txt', 'w')

for igrain in range(num_grains):
    my_materials.append(material('in718','umat',folder='umat_cp_phen_iso'))
    orientations.append(2*np.pi*np.random.rand())

    R1=[np.cos(orientations[-1]), -np.sin(orientations[-1]),0 ]
    R2=[np.sin(orientations[-1]),  np.cos(orientations[-1]),0 ]
    ffm.write('%f %f %f %f %f %f %f\n' % (R1[0],R1[1],R1[2],R2[0],R2[1],R2[2],0.))
    my_materials[-1].set_properties(props=np.append(np.append(R1,R2),0),sdv_num=76)
    
ffm.close()

#Define loads
my_simulation.set_load_step(F_ave_goal=[[1.02,0,0],[0,1.0,0],[0,0,1.0]],\
                       stress_ave_goal=[[0,0,0],[0,0,0],[0,0,0]],\
                       timer=[1e-2,1.,1e-4,0.1],
                       info=[9,10,11,12,13,14,15,16,17,18,19,20,21],frec=1,incfix=0,control=[[0,1,0],[1,1,0],[0,0,0]])

# Solving sequence
my_simulation.generate_green()
my_simulation.set_FP(my_materials)
my_simulation.solve(output='results/Test_polyX1')

# Postprocessing
toParaview(my_simulation)