### Variational approach: linear case, load control test
### FFTMAD version 05/2019
### Linear simulation, testing strain and mixed control
### 3D

## STRESS AND MIXED CONTROL

from INPUT.RVE_generation import spheres_period
from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from POST.toParaview import toParaview
import matplotlib.pyplot as plt


folder='results/'
nvoxels=2**6

#define simulation
my_simulation=simulation('Test_stresscontrol','non-linear','variational-nw-cg-small')

#define options
my_simulation.set_options(nlgeom='no')
my_simulation.set_tolerances(toler_nw=1e-5,toler_lin=1e-7,maxiter_cg=1000)

#Model geometry

my_simulation.ndim=3
my_simulation.n=[nvoxels,nvoxels,nvoxels]
my_simulation.L=[1.,1.,1.]
my_simulation.prop=spheres_period(my_simulation.ndim,1,0.2,my_simulation.n,my_simulation.L)
  

# Material models and Properties
      
E=70.0E3
nu=0.33
E2=100*E
nu2=0.25
my_materials=[]
my_materials.append(material('Matrix','linear-elastic'))
my_materials[-1].set_properties(E=E,nu=nu)
my_materials.append(material('Inclusion','linear-elastic'))
my_materials[-1].set_properties(E=E2,nu=nu2)


#Define loads
my_simulation.set_load_step(strain_ave_goal=[[0.001,0,0],[0,0,0],[0,0,0]],\
 timer=[1,1,1,1],stress_ave_goal=[[0,0,0],[0,0,0],[0,0,0]],\
 info=range(0),frec=1,incfix=0,control=[[0,1,1],[1,1,1],[1,1,1]])

# Solving sequence
my_simulation.generate_green()
my_simulation.set_FP(my_materials)
my_simulation.solve(output=folder+my_simulation.jobname)

#post

toParaview(my_simulation)
print ('stress:', my_simulation.stress_ave)
print ('strain:', my_simulation.strain_ave)