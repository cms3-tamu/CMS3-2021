# -*- coding: utf-8 -*-
"""
Created on Sun Oct  9 14:54:16 2016

@author: javierseguradoescudero
"""
### PROBLEM 1: 
## a) DFT, FFT, derivatives and convolutions


## Discrete Fourier Transform and FFT

import matplotlib.pyplot as plt
import numpy as np
import time,timeit
from DFT_funcs import *

N=2**5
L=10.

ns=list(range(0,1+(N-1)//2))+list(range(-(N-1)//2,0))
n=range(N)
x=np.array(n)*L/N

# PART 1: Definition of DFT and transfornations

# Definition of the discrete function
f=np.sin(2*np.pi*x/L)**2
df_analytical = 2*(2*np.pi/L)*np.sin(2*np.pi*x/L)*np.cos(2*np.pi*x/L)

plt.plot(x,f,x,df_analytical)
plt.show()
# 1.1 Checking different algorithms and times
print ('DFT algorithm1')
start=time.time()
f_dft1=dft(f)
end=time.time()
t1=end-start

print ('DFT algorithm2')
start=time.time()
f_dft2=dft_v2(f)
end=time.time()
t2=end-start

print ('FFT Cooley-Tuckey')
start=time.time()
f_fft_cooley=fft_cooley(f)
end=time.time()
t3=end-start

# 1.2 Numpy fft
print ('numpy fft')
start=time.time()
f_fft=np.fft.fft(f)
end=time.time()
t4=end-start

print ('Time comparison')
print ('times:',t1,t2,t3,t4)

# 1.3 Checking fft(ifft(f))==f
print('Check of inverse transform using FFT')
fback=ifft_cooley(f_dft1)
print(np.isclose(f,fback))

# 1.4 Times. 
times_DFT=[]
times_FFT=[]
npoints=[]
for i in range(3,13):

    N=2**i
    npoints.append(N)
    
    ## Here define N,ns,x, and f
    ns=list(range(0,1+(N-1)//2))+list(range(-(N-1)//2,0))
    n=range(N)
    x=np.array(n)*L/N

    f=np.sin(2*np.pi*x/L)**2
    
    start=time.time()
    for times in range(10):
        f_dft2=dft_v2(f)
    end=time.time()
    t=(end-start)/10
    times_DFT.append(t)
    
    start=time.time()
    for times in range(10):
        f_fft=np.fft.fft(f)
    end=time.time()
    t=(end-start)/10
    times_FFT.append(t)

    
    ## Here do the same for the fft function
    
plt.plot(npoints,times_FFT)

# 1.5 function derivative. STUDENT, CHANGE THE FUNCTION

# HERE DEFINE F
ns=list(range(0,1+(N-1)//2))+list(range(-(N-1)//2,0))
n=range(N)
x=np.array(n)*L/N
f=np.sin(2*np.pi*x/L)**2
df_analytical = 2*(2*np.pi/L)*np.sin(2*np.pi*x/L)*np.cos(2*np.pi*x/L)

# HERE OBTAIN FFT(f)

# HERE DERIVE IT In f SPACE

#df_fft=f_fft*1j*2*np.pi*np.array(ns)/L
#df = idft_v2(df_fft)
#df2 = np.fft.ifft(df_fft)

#plt.plot(x,f,x,fback,x,df,'*',x,df_analytical,'+')

#1.6 Redefine N=5 and f and check the FFT to see symmetries
N=5


## Here define N,ns,x, and f
ns=list(range(0,1+(N-1)//2))+list(range(-(N-1)//2,0))
n=range(N)
x=np.array(n)*L/N
f=np.sin(2*np.pi*x/L)**2
fft_f=np.fft.fft(f)
print('FFt(f)')
print(fft_f)




