#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 19 12:23:31 2019

@author: javierseguradoescudero
"""
### PROBLEM 1: 
## b) 2D FFT


import numpy as np
import matplotlib.pyplot as plt


N=2**7
L=1.
xvec=np.array(np.meshgrid(np.arange(-L/2,L/2,L/N),np.arange(-L/2,L/2,L/N), indexing='ij'))

## 1.1
f=np.cos(2*np.pi*(xvec[0,:])*(xvec[1,:]))**2

plt.contourf(xvec[0],xvec[1],f,20)
# 1.3 
f_fft=np.fft.fft2(f)
#1.4
f_back=np.fft.ifft2(f_fft)

plt.contourf(xvec[0],xvec[1],f_back,20)

## 1.5 gradient! 
ns=list(range(0,1+(N-1)//2))+list(range(-(N-1)//2,0))
xi=np.array(ns)/L
gradx=np.zeros([N,N],dtype=complex)
grady=np.zeros([N,N],dtype=complex)

for i1 in range(N):
    for i2 in range(N):
        gradx[i1,i2] = 1j*2*np.pi*xi[i1]*f_fft[i1,i2]
        grady[i1,i2] = 1j*2*np.pi*xi[i2]*f_fft[i1,i2]
gradx=np.fft.ifft2(gradx)
grady=np.fft.ifft2(grady)
plt.contourf(xvec[0],xvec[1],gradx,20)

## 1.6 STUDENT: COMPLETE FOR DIVERGENCE
## Define g_x and g_y
#for i1 in range(N):
#    for i2 in range(N):
#        div_FFT = ...