### Script for elastic response in 3D
### FFTMAD version 05/2019
### Basic use of linear solvers: circle/sphere in square/cube
### 2D and 3D

from SOLVERS.solverclass import simulation
from MAT_MODELS.materials import material
from INPUT.RVE_generation import one_sphere
from POST.toParaview import toParaview


# Initializing a simulation

my_simulation=simulation('Tutorial_1','linear','basic-strain')
my_simulation.ndim=3

# Generation of the microstructure        
N=2**6
my_simulation.n=[N,N,N]
my_simulation.L=[1.,1.,1.]
my_simulation.prop=one_sphere(my_simulation.ndim,[0.5,0.5,0.5], \
 0.196,my_simulation.n,my_simulation.L)    
my_simulation.set_tolerances(toler_lin=1e-6)
# Material models and Properties
my_materials=[]
my_materials.append(material('aluminio','linear-elastic'))
my_materials.append(material('SiC','linear-elastic'))
my_materials[0].set_properties(E=70E7,nu=0.3)
my_materials[1].set_properties(E=70E9,nu=0.3)

#Loads
my_simulation.set_load_step(strain_ave_goal=[[1E-1 ,0,0],[0,0,0],[0,0,0]])

Eaver=(my_materials[0].E+my_materials[1].E)/2
nuaver=(my_materials[0].nu+my_materials[1].nu)/2

# Solving sequence
my_simulation.generate_green(E0=Eaver,nu0=nuaver)
my_simulation.set_FP(my_materials)
my_simulation.solve(output='results/'+my_simulation.jobname)

# Postprocessing
toParaview(my_simulation)

print ('stress:', my_simulation.stress_ave)
print ('strain:', my_simulation.strain_ave)