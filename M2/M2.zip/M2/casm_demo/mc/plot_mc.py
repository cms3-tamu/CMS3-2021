import json
from os.path import exists, join
import pandas

def read(base, col, data):

  path = base 
  
    
  ### open Monte Carlo results.json file
  with open(join(path, 'results.json'), 'r') as f:
    res = pandas.read_json(f)
    
  if base not in data:
    data[base] = []
  data[base].append(res[col])
    

data = dict()
col = ['<comp(a)>', 'param_chem_pot(a)', 'T', 'Beta', '<potential_energy>']
read("T100", col, data)
read("T300", col, data)
read("T600", col, data)

import matplotlib.pyplot as plt

x_val = 'param_chem_pot(a)'
y_val = '<comp(a)>'

  
plt.plot(data['T100'][0][x_val], data['T100'][0][y_val], 'bo-', label='T = 100 K')
plt.plot(data['T300'][0][x_val], data['T300'][0][y_val], 'ro-', label='T = 300 K')
plt.plot(data['T600'][0][x_val], data['T600'][0][y_val], 'go-', label='T = 600 K')
  

plt.xlabel(x_val)
plt.ylabel(y_val)
plt.legend(loc=0)
plt.ylim([-0.1,1.1])
plt.xlim([-0.05,0.05])
plt.show()

