function sys = get_slip_system(links)

% FCC crystal
b0 = 1/sqrt(2)*[0,1,1;0,-1,1;1,0,1;-1,0,1;-1,1,0;1,1,0];
n0 = 1/sqrt(3)*[-1,1,1;1,1,1;-1,-1,1;1,-1,1];

b = links(:,3:5);
b = b./repmat(sqrt(sum(b.^2,2)),1,3);
n = links(:,6:8);
n = n./repmat(sqrt(sum(n.^2,2)),1,3);

tol = 1e-4;
sys = zeros(size(links,1),1);
for s=1:size(links,1)

    bid = 0;
    for i=1:size(b0,1)
        if abs(abs(dot(b(s,:),b0(i,:)))-1) < tol
            bid = i;
            break;
        end
    end

    nid = 0;
    for i=1:size(n0,1)
        if abs(abs(dot(n(s,:),n0(i,:)))-1) < tol
            nid = i;
            break;
        end
    end

    if nid == 1
        if bid == 2
            sys(s) = 1; % A2
        elseif bid == 3
            sys(s) = 2; % A3
        elseif bid == 6
            sys(s) = 3; % A6
        else
            sys(s) = 0;
        end
    elseif nid == 2
        if bid == 2
            sys(s) = 4; % B2
        elseif bid == 4
            sys(s) = 5; % B4
        elseif bid == 5
            sys(s) = 6; % B5
        else
            sys(s) = 0;
        end
    elseif nid == 3
        if bid == 1
            sys(s) = 7; % C1
        elseif bid == 3
            sys(s) = 8; % C3
        elseif bid == 5
            sys(s) = 9; % C5
        else
            sys(s) = 0;
        end
    elseif nid == 4
        if bid == 1
            sys(s) = 10; % D1
        elseif bid == 4
            sys(s) = 11; % D4
        elseif bid == 6
            sys(s) = 12; % D6
        else
            sys(s) = 0;
        end
    else
        sys(s) = 0; % Junction or non-native FCC system
    end

end

end

