% Example of solution to compute junction maps in FCC

close all;
clear all;
clc;

% Global parameters
global Bscrew Bedge Bclimb Bline

maxconnections=8;
lmax = 1000;
lmin =  200;
a=10;lmin/sqrt(6);
MU = 1.3e11;
NU = 0.309; % for BCC Mo
Ec = MU/(4*pi)*log(a/0.1);

areamin=lmin*lmin*sin(60/180*pi)*0.5; % minimum discretization area
areamax=20*areamin; % maximum discretization area
dt0=1e-5;           %maximum time step
plotfreq=1;       %plot nodes every how many steps
plim=2000;          %plot x,y,z limit (nodes outside not plotted)

viewangle=[60 30];
printfreq=1;      %print out information every how many steps
printnode=1;
plotfun='plotnodescolor';

integrator='int_trapezoid';
rann = 10;       %annihilation distance (capture radius)
%rntol=1e-1;       %tolerance for integrating equation of motion
rntol = 2*rann;      % on Tom's suggestion
rmax=30;
doremesh    =1;
docollision =1;
doseparation=1;

Bscrew=1e0;
Bedge=1e0;
Bclimb=1e2;
Bline=1.0e-4*min(Bscrew,Bedge);

appliedstress = zeros(3,3);
mobility='mobfcc0';
totalsteps=100;



% Junction configuration

L = 2000; % Line length
junction = 'lomer';

% Dislocation line 1
b1 = 1/2*[0,1,1];
n1 = 1/sqrt(3)*[1,1,-1];

% Dislocation line 2
if strcmp(junction,'lomer')
    % Lomer
    b2 = 1/2*[1,0,-1];
    n2 = 1/sqrt(3)*[1,1,1];
elseif strcmp(junction,'glissile')
    % Glissile
    b2 = 1/2*[1,0,-1];
    n2 = 1/sqrt(3)*[1,-1,1];
elseif strcmp(junction,'hirth')
    % Hirth
    b2 = 1/2*[0,-1,1];
    n2 = 1/sqrt(3)*[1,1,1];
elseif strcmp(junction,'colinear')
    % Colinear
    b2 = 1/2*[0,-1,-1];
    n2 = 1/sqrt(3)*[1,-1,1];
end


% Define line directions
ej = cross(n1,n2);
ej = ej/norm(ej);

e1 = cross(ej,n1);
e2 = cross(ej,n2);

phi1 = [5:30:180];
phi2 = [5:30:180];

map = zeros(numel(phi1),numel(phi2));

for i=1:numel(phi1)
    for j=1:numel(phi2)
        
        fprintf('phi1 = %f, phi2 = %f\n',phi1(i),phi2(j));

        t1 = cos(phi1(i)*pi/180)*ej + sin(phi1(i)*pi/180)*e1;
        t2 = cos(phi2(j)*pi/180)*ej + sin(phi2(j)*pi/180)*e2;

        % Orthogonal distance between the lines
        R = cross(t1,t2);
        R = R/norm(R);
        d = 10;
        R = d*R;

        rn = [ -t1*L - R 7
                t1*0 - R 0
                t1*L - R 7
               -t2*L + R 7
                t2*0 + R 0
                t2*L + R 7 ];

        links = [ 1 2   b1 n1
                  2 3   b1 n1
                  4 5   b2 n2
                  5 6   b2 n2 ];
              
        % Run DDLab
        dd3d
        
        
        % Identify if a junction segment is present
        sys = get_slip_system(links);
        if numel(unique(sys)) > 2
            map(i,j) = 1;
        end

    end
end



clf(figure(2));
[mx,my] = ndgrid(phi1,phi2);
ind0 = find(map==0);
ind1 = find(map~=0);
hold on;
scatter(mx(ind0),my(ind0),'ob');
scatter(mx(ind1),my(ind1),'+r');
hold off;
xlabel('phi1');
ylabel('phi2');



return;


% Angle analysis using Kroupa's formula

phi = linspace(0.1,180,20);
map2 = zeros(numel(phi),numel(phi));

for n=1:length(phi)
    for m=1:length(phi)
        phi1 = phi(n)*pi/180;
        phi2 = phi(m)*pi/180;

        t1 = cos(phi1)*ej + sin(phi1)*e1;
        t2 = cos(phi2)*ej + sin(phi2)*e2;

        F = Kroupa(b1,b2,t1,t2,MU,NU);

        map2(n,m) = F;
    end
end

figure(3);
[mx,my] = ndgrid(phi,phi);
surf(mx,my,map2);
shading interp;
view(2);
xlabel('phi1');
ylabel('phi2');

