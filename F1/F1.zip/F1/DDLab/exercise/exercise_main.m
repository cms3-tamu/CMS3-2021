
close all;
clear all;
clc;

% Global parameters
global Bscrew Bedge Bclimb Bline

maxconnections=8;
lmax = 1000;
lmin =  200;
a=10;lmin/sqrt(6);
MU = 1.3e11;
NU = 0.309; % for BCC Mo
Ec = MU/(4*pi)*log(a/0.1);

areamin=lmin*lmin*sin(60/180*pi)*0.5; % minimum discretization area
areamax=20*areamin; % maximum discretization area
dt0=1e-5;           %maximum time step
plotfreq=1;       %plot nodes every how many steps
plim=2000;          %plot x,y,z limit (nodes outside not plotted)

viewangle=[60 30];
printfreq=1;      %print out information every how many steps
printnode=1;
plotfun='plotnodescolor';

integrator='int_trapezoid';
rann = 10;       %annihilation distance (capture radius)
%rntol=1e-1;       %tolerance for integrating equation of motion
rntol = 2*rann;      % on Tom's suggestion
rmax=30;
doremesh    =1;
docollision =1;
doseparation=1;

Bscrew=1e0;
Bedge=1e0;
Bclimb=1e2;
Bline=1.0e-4*min(Bscrew,Bedge);

appliedstress = zeros(3,3);
mobility='mobfcc0';
totalsteps=100;



% Junction configuration

% Dislocation line 1
b1 = 1/2*[0,1,1];
n1 = 1/sqrt(3)*[1,1,-1];

% Dislocation line 2
% ...

rn = [];
links = [];

% Run DDLab
dd3d

