function plotnodescolor(rn,links,plim)

%plot nodes
%only those nodes within [-plim,plim] in x,y,z directions are plotted

types = fcc_color(links(:,3:5),links(:,6:8));
col = ['r','b','g','m','k'];

plot3(0,0,0); hold on;
LINKMAX=length(links(:,1));
for i=1:LINKMAX,
    n0=links(i,1);
    n1=links(i,2);
    if((n0~=0)&(n1~=0)&(max(max(abs(rn([n0,n1],:))))<=plim))
        %filter out "infinity" lines
        plot3(rn([n0,n1],1),rn([n0,n1],2),rn([n0,n1],3),[col(types(i)) '.-']);
    end 
end
hold off
axis equal
grid

end

function type = fcc_color(b,n)

% FCC crystal
b0 = 1/sqrt(2)*[0,1,1;0,-1,1;1,0,1;-1,0,1;-1,1,0;1,1,0];
n0 = 1/sqrt(3)*[-1,1,1;1,1,1;-1,-1,1;1,-1,1];

bn = b./repmat(sqrt(sum(b.^2,2)),1,3);
nn = n./repmat(sqrt(sum(n.^2,2)),1,3);
    
b1 = abs(abs(dot(bn,repmat(b0(1,:),size(bn,1),1),2))-1);
b2 = abs(abs(dot(bn,repmat(b0(2,:),size(bn,1),1),2))-1);
b3 = abs(abs(dot(bn,repmat(b0(3,:),size(bn,1),1),2))-1);
b4 = abs(abs(dot(bn,repmat(b0(4,:),size(bn,1),1),2))-1);
b5 = abs(abs(dot(bn,repmat(b0(5,:),size(bn,1),1),2))-1);
b6 = abs(abs(dot(bn,repmat(b0(6,:),size(bn,1),1),2))-1);
[mb,ib] = min([b1,b2,b3,b4,b5,b6],[],2);
ib(mb>1e-4) = 7;

n1 = abs(abs(dot(nn,repmat(n0(1,:),size(nn,1),1),2))-1);
n2 = abs(abs(dot(nn,repmat(n0(2,:),size(nn,1),1),2))-1);
n3 = abs(abs(dot(nn,repmat(n0(3,:),size(nn,1),1),2))-1);
n4 = abs(abs(dot(nn,repmat(n0(4,:),size(nn,1),1),2))-1);
[~,in] = min([n1,n2,n3,n4],[],2);

type = in;
type(ib==7) = 5;

end
